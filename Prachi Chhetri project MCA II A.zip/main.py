import pandas as pd
import sweetviz as sv

df = pd.read_csv('peopleofDehradun.csv')
print(df)
print(df.shape)

# Generate a report
report = sv.analyze(df)
report.show_html('income_report.html')


pd.set_option('display.max_rows', None)  # Show all rows
pd.set_option('display.max_columns', None)  # Show all columns

print(df)